/********************************************************************/
// HC12 Program:  ICA03 - PortJ
// Processor:     MC9S12XDP512
// Bus Speed:     20 MHz
// Author:        Connor Marsh
// Details:                  
// Date:          10-09-24
// Revision History :
// 



/********************************************************************/
// Library includes
/********************************************************************/

//Other system includes or your includes go here
#include <stdlib.h>
#include <stdio.h>
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include "clock.h"
#include "pit.h"
#include "SWLED.h"


/********************************************************************/
//Defines
/********************************************************************/

/********************************************************************/
// Local Prototypes
/********************************************************************/
/********************************************************************/
// Global Variables
/********************************************************************/


/********************************************************************/
// Constants
/********************************************************************/
unsigned long counter;
unsigned char start;
/********************************************************************/
// Main Entry
/********************************************************************/
void main(void)
{
  //Any main local variables must be declared here
  // main entry point
  _DISABLE_COP();
  EnableInterrupts;
  
/********************************************************************/
  // one-time initializations
/********************************************************************/
Clock_Set20MHZ();
SWL_Init();

//100ms
PITMTLD0 = 49;
PITLD0 =  399;
start = 0;
PIT_InitChannel(PIT_CH0, PIT_MT0, PIT_IEN);
PIT_Start();
counter = 2000;


/********************************************************************/
  // main program loop
/********************************************************************/

  for (;;)
  {
     if(SWL_PUSHED(SWL_CTR)&&!start) {
      counter=0;  
      start=1;
     }
     if(counter>2000) counter=2000;
     if(counter<=1000) SWL_ON(SWL_RED); 
     else {
      SWL_OFF(SWL_RED);
      if(!SWL_PUSHED(SWL_CTR)) start=0;
     }
     
  }
}

  

/********************************************************************/
// Functions
/********************************************************************/
/********************************************************************/
// Interrupt Service Routines
/********************************************************************/
interrupt VectorNumber_Vpit0 void Vpit0_ISR(void)
{
PITTF |= PITTF_PTF0_MASK;
counter++; 
SWL_TOG(SWL_RED);
}